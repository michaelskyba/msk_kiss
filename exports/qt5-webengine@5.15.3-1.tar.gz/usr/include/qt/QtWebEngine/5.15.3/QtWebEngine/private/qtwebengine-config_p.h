#define QT_FEATURE_webengine_qml 1
#define QT_FEATURE_webengine_testsupport -1
#define QT_FEATURE_webengine_ui_delegates 1
