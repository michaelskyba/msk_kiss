#define QT_FEATURE_pdf_v8 -1
#define QT_FEATURE_pdf_xfa -1
#define QT_FEATURE_pdf_xfa_bmp -1
#define QT_FEATURE_pdf_xfa_gif -1
#define QT_FEATURE_pdf_xfa_png -1
#define QT_FEATURE_pdf_xfa_tiff -1
